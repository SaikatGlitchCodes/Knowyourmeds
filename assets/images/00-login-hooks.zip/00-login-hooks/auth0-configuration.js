const config = {
  clientId: "{yourClientId}",
  domain: "{yourDomain}"
};

export default config;